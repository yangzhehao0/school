<?php

/**
 * 模块语言包-冒泡
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	'bubble_praise_table_nickname'				=>	'用户',
	'bubble_praise_table_add_time'				=>	'点赞时间',
	'bubble_so_keyword_tips'					=>	'昵称/手机/邮箱/说说',
);
?>