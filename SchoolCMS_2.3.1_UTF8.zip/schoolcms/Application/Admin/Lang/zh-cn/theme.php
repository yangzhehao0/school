<?php

/**
 * 模块语言包-主题管理
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	'theme_nav_home'			=>	'当前主题',
	'theme_nav_upload'			=>	'主题安装',
	'theme_upload_tips'			=>	'上传一个zip压缩格式的主题安装包',
	'theme_upload_error'		=>	'文件格式有误，请上传zip压缩包',
	'theme_delete_error'		=>	'不能删除正在使用的主题',
	'theme_author_text'			=>	'作者：',
	'theme_ver_text'			=>	'适用版本：',
);
?>