<?php

/**
 * 模块语言包-文章分类
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	// 添加/编辑
	'articleclass_add_name'					=>	'文章分类添加',
	'articleclass_edit_name'				=>	'文章分类编辑',
);
?>