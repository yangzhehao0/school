<?php

/**
 * 模块语言包-时段
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	// 添加/编辑
	'interval_add_name'					=>	'时段添加',
	'interval_edit_name'				=>	'时段编辑',
	'interval_name_format'				=>	'时段格式错误 格式如 10:00-11:30',
	'interval_name_format_tips'			=>	'格式如 10:00-11:30',
);
?>