<?php

/**
 * 模块语言包-短信设置
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	'sms_sms_nav_name'			=>	'短信设置',
	'sms_message_nav_name'		=>	'消息模板',
);
?>