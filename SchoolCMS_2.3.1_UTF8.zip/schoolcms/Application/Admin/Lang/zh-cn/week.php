<?php

/**
 * 模块语言包-周
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	// 添加/编辑
	'week_add_name'					=>	'周添加',
	'week_edit_name'				=>	'周编辑',
);
?>