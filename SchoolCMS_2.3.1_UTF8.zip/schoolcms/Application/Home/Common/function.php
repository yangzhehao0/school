<?php

/**
 * 模块方法
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */

function test2()
{
	echo 'test2()';
}
?>