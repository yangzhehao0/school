<?php

/**
 * 模块语言包-文章详情
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	'article_add_time_text'				=>	'发布日期',
	'article_access_count_text'			=>	'浏览次数',
	'article_on_exist_error'			=>	'文章不存在或已删除',
);
?>