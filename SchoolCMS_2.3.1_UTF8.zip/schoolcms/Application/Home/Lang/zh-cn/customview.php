<?php

/**
 * 模块语言包-自定义页面
 * @author   Devil
 * @blog     http://gong.gg/
 * @version  0.0.1
 * @datetime 2016-12-01T21:51:08+0800
 */
return array(
	'customview_on_exist_error'				=>	'页面不存在或已删除',
);
?>